/* SpeedUp page v2: reveals, hero parallax, device scaling, role tabs, checklist, 20-second auto demo. No dependencies. */
(function(){
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

/* reveals + split lines */
$$('[data-split] .ln').forEach(ln=>{const s=document.createElement('span');s.innerHTML=ln.innerHTML;ln.innerHTML='';ln.appendChild(s)});
$$('[data-split]').forEach(h=>h.querySelectorAll('.ln').forEach((ln,i)=>ln.style.setProperty('--i',i)));
const io=new IntersectionObserver(es=>es.forEach(en=>{ if(en.isIntersecting){en.target.classList.add('in'); io.unobserve(en.target)} }),{rootMargin:'0px 0px -10% 0px',threshold:.05});
$$('[data-reveal],[data-split]').forEach(el=>io.observe(el));

/* hero parallax + top bar */
const heroImg=$('.hero-media img'), top=$('#top');
function onScroll(){const y=window.scrollY;
  if(heroImg&&!reduced) heroImg.style.transform=`translateY(${(y*.22).toFixed(1)}px)`;
  top.classList.toggle('solid',y>60);
}
addEventListener('scroll',onScroll,{passive:true}); onScroll();

/* device scale to fit its column */
const wrap=$('.device-wrap');
function fit(){const w=wrap.clientWidth; const maxH=innerWidth<=900?innerHeight*.8:innerHeight*.78; const s=Math.min(1, w/414, maxH/868); document.documentElement.style.setProperty('--s',s.toFixed(4))}
fit(); addEventListener('resize',()=>{fit()}); addEventListener('load',fit);

/* role tabs <-> app */
$$('#roles [data-role]').forEach(b=>b.addEventListener('click',()=>{ stopDemo(); if(window.SU) SU.setRole(b.dataset.role) }));
document.addEventListener('click',e=>{ const b=e.target.closest('#rolebar [data-role]'); if(!b) return; stopDemo(); $$('#roles [data-role]').forEach(x=>x.classList.toggle('on',x.dataset.role===b.dataset.role)) });
document.addEventListener('su:action',e=>{ const li=$(`#checklist [data-check="${e.detail.type}"]`); if(li) li.classList.add('done') });

/* smooth anchor scroll */
$$('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{ const el=$(a.getAttribute('href')); if(!el) return; e.preventDefault(); el.scrollIntoView({behavior:reduced?'auto':'smooth',block:'start'}) }));

/* 20-second auto demo */
const playBtn=$('#playDemo'), cap=$('#demoCap');
let demoTimers=[], running=false;
function say(t){cap.textContent=t;cap.classList.add('on')}
function at(ms,fn){demoTimers.push(setTimeout(fn,ms))}
function stopDemo(){ if(!running) return; running=false; demoTimers.forEach(clearTimeout); demoTimers=[]; playBtn.classList.remove('running'); cap.classList.remove('on') }
function runDemo(){
  if(!window.SU) return; if(running){stopDemo();return}
  running=true; playBtn.classList.add('running');
  const roleBtn=r=>$$('#roles [data-role]').forEach(x=>x.classList.toggle('on',x.dataset.role===r));
  SU.markZayed(false);
  at(0,()=>{ roleBtn('parent'); SU.show('parent','home'); say('Zayed has 5 of 8 sessions left. His mother can see it.') ; setTimeout(()=>SU.focus('.pack'),400)});
  at(4200,()=>{ roleBtn('coach'); SU.show('coach','today'); say("Saturday 10:00. Coach Shiko opens his class.") });
  at(7200,()=>{ SU.show('coach','class','c1'); say('Five swimmers. He marks Zayed present.') });
  at(10200,()=>{ SU.markZayed(true); say('One tap. The package drops to 4.') });
  at(13200,()=>{ roleBtn('parent'); SU.show('parent','home'); say('Noor\'s phone updates. 4 of 8 left. Nobody typed anything.'); setTimeout(()=>SU.focus('.pack'),400) });
  at(17200,()=>{ roleBtn('admin'); SU.show('admin','dash'); say('The office sees attendance, balances and payments, live.') });
  at(21000,()=>{ running=false; playBtn.classList.remove('running'); say('That\'s the whole system. Now you try.') ; setTimeout(()=>cap.classList.remove('on'),3500) });
}
playBtn.addEventListener('click',runDemo);
})();
