/* Motion engine for the SpeedUp prototype page. Hashmi Digital.
   Smooth scroll (lerp), one device travelling between slots, scroll-driven story, reveals.
   No dependencies. Respects prefers-reduced-motion. */
(function(){
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const finePointer=matchMedia('(pointer: fine)').matches;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const easeIO=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
const easeOut=t=>1-Math.pow(1-t,3);

/* ---------- 1. smooth scroll (Lenis-style lerp on wheel, native elsewhere) ---------- */
let target=window.scrollY, current=window.scrollY, animating=false, lastNative=window.scrollY;
function maxScroll(){return document.documentElement.scrollHeight-window.innerHeight}
function onWheel(e){
  if(e.ctrlKey) return; // pinch zoom
  // let the phone screen scroll natively when the pointer is over it and it can scroll
  const sc=e.target.closest&&e.target.closest('.screen,.sheet');
  if(sc){const canDown=sc.scrollTop+sc.clientHeight<sc.scrollHeight-1, canUp=sc.scrollTop>0; if((e.deltaY>0&&canDown)||(e.deltaY<0&&canUp)) return;}
  e.preventDefault();
  const d=e.deltaMode===1?e.deltaY*18:e.deltaMode===2?e.deltaY*window.innerHeight:e.deltaY;
  target=clamp(target+d,0,maxScroll());
  if(!animating){animating=true;requestAnimationFrame(tick)}
}
function tick(){
  current=lerp(current,target,.11);
  if(Math.abs(target-current)<.4){current=target;animating=false}
  window.scrollTo(0,current); lastNative=current;
  frame();
  if(animating) requestAnimationFrame(tick);
}
if(finePointer&&!reduced){
  addEventListener('wheel',onWheel,{passive:false});
  addEventListener('scroll',()=>{ if(!animating&&Math.abs(window.scrollY-lastNative)>1){target=current=lastNative=window.scrollY} },{passive:true});
}
addEventListener('scroll',()=>{ if(!animating) requestAnimationFrame(frame) },{passive:true});

/* ---------- 2. reveals + split lines ---------- */
$$('[data-split] .ln').forEach(ln=>{const s=document.createElement('span');s.innerHTML=ln.innerHTML;ln.innerHTML='';ln.appendChild(s)});
$$('[data-split]').forEach(h=>h.querySelectorAll('.ln').forEach((ln,i)=>ln.style.setProperty('--i',i)));
const io=new IntersectionObserver(es=>es.forEach(en=>{ if(en.isIntersecting){en.target.classList.add('in'); io.unobserve(en.target)} }),{rootMargin:'0px 0px -12% 0px',threshold:.05});
$$('[data-reveal],[data-split],.pathway').forEach(el=>io.observe(el));

/* ---------- 3. the travelling device ---------- */
const device=$('#device'), stage=$('#stage');
const slots={hero:$('.slot-hero'),story:$('.slot-story'),play:$('.slot-play')};
const hero=$('#hero'), story=$('#story'), play=$('#play');
const BASE_W=414, BASE_H=868;
let keys=[]; // {y, cx, cy, s, ry, rx}
function docRect(el){const r=el.getBoundingClientRect();return {x:r.left+window.scrollX,y:r.top+window.scrollY,w:r.width,h:r.height}}
function slotFrame(slotEl,atScroll,extra){
  const r=docRect(slotEl);
  const s=Math.min(r.h/BASE_H, r.w/BASE_W);
  return Object.assign({y:atScroll, cx:r.x+r.w/2, cy:r.y-atScroll+r.h/2, s},extra);
}
function measure(){
  const sTop=story.offsetTop, sEnd=sTop+story.offsetHeight-window.innerHeight;
  const pTop=play.offsetTop;
  const mobile=innerWidth<=900;
  keys=[
    slotFrame(slots.hero,0,{ry:mobile?0:-16,rx:mobile?0:6,tz:mobile?0:-40,pin:!mobile}),
    slotFrame(slots.story,sTop,{ry:0,rx:0,tz:0,pin:true}),
    Object.assign(slotFrame(slots.story,sTop,{ry:0,rx:0,tz:0,pin:true}),{y:sEnd}),
    slotFrame(slots.play,pTop,{ry:0,rx:0,tz:0}),
  ];
  // the hero slot measured at scroll 0: its cy is viewport-relative when scrolled to 0
  keys[0].cy=docRect(slots.hero).y+docRect(slots.hero).h/2;
}
function frameAt(y){
  const K=keys;
  const at=(k,y)=>k.pin?k.cy:k.cy-(y-k.y); // pinned keys hold a viewport position, anchored keys drift with the page
  if(y<=K[0].y) return Object.assign({},K[0],{cy:at(K[0],y)});
  for(let i=0;i<K.length-1;i++){
    const a=K[i],b=K[i+1];
    if(y>=a.y&&y<=b.y){
      const t=b.y===a.y?1:easeIO((y-a.y)/(b.y-a.y));
      const acy=at(a,y), bcy=at(b,y);
      return {cx:lerp(a.cx,b.cx,t),cy:lerp(acy,bcy,t),s:lerp(a.s,b.s,t),ry:lerp(a.ry,b.ry,t),rx:lerp(a.rx,b.rx,t),tz:lerp(a.tz,b.tz,t)};
    }
  }
  const l=K[K.length-1]; return Object.assign({},l,{cy:at(l,y)});
}
let lastY=-1;
function placeDevice(y){
  const f=frameAt(y);
  // after the play key, the stage scrolls away with the journey; keep device at play frame
  const x=f.cx-BASE_W/2, yy=f.cy-BASE_H/2;
  device.style.transform=`translate3d(${x.toFixed(2)}px,${yy.toFixed(2)}px,0) perspective(1600px) rotateY(${f.ry.toFixed(2)}deg) rotateX(${f.rx.toFixed(2)}deg) scale(${f.s.toFixed(4)})`;
}
function heroFade(y){
  const h=innerHeight;const t=clamp(y/(h*.6),0,1);
  const copy=$('.hero-copy'), foot=$('.hero-foot');
  copy.style.opacity=(1-easeOut(t)).toFixed(3); copy.style.transform=`translateY(${(-40*t).toFixed(1)}px)`;
  if(foot){foot.style.opacity=(1-t).toFixed(3)}
  $('.lanes').style.transform=`translateY(${(y*.12).toFixed(1)}px)`;
}

/* ---------- 4. story steps drive the real app ---------- */
const steps=$$('.step'); let activeStep=-1;
function applyStep(i){
  if(i===activeStep) return; const prev=activeStep; activeStep=i;
  steps.forEach((s,k)=>s.classList.toggle('on',k===i));
  if(i<0||!window.SU) return;
  const st=steps[i]; const [role,view]=st.dataset.screen.split(':');
  // undo the marking if scrolling back above step 5
  if(prev>=4&&i<4) SU.markZayed(false);
  SU.show(role,view,st.dataset.arg);
  if(st.dataset.action==='markZayed') setTimeout(()=>{ if(activeStep===i) SU.markZayed(true) },520);
  if(st.dataset.focus==='package') setTimeout(()=>{ if(activeStep===i) SU.focus('.pack') },500);
}
function storyFrame(y){
  const sTop=story.offsetTop, vh=innerHeight;
  const centre=y+vh*.5;
  let idx=-1;
  if(y>sTop-vh*.55 && y<sTop+story.offsetHeight-vh*.45){
    idx=0; steps.forEach((s,k)=>{ if(centre>=s.offsetTop+sTop) idx=k; });
  }
  applyStep(idx);
  // progress-driven text: full at centre, gone at 42% of a viewport away
  const mobile=innerWidth<=900;
  steps.forEach(s=>{
    const el=s.firstElementChild; const sc=s.offsetTop+sTop+s.offsetHeight*.5;
    const d=(sc-centre)/vh; const a=1-clamp(Math.abs(d)/(mobile?.26:.42),0,1); const o=reduced?1:easeOut(a);
    el.style.opacity=o.toFixed(3); el.style.transform=(reduced||mobile)?'none':`translateY(${(d*44).toFixed(1)}px)`;
  });
}
/* ---------- 5. playground: role tabs, checklist, jump links ---------- */
$$('#roles [data-role]').forEach(b=>b.addEventListener('click',()=>{ if(window.SU) SU.setRole(b.dataset.role) }));
document.addEventListener('click',e=>{ const b=e.target.closest('#rolebar [data-role]'); if(!b) return; $$('#roles [data-role]').forEach(x=>x.classList.toggle('on',x.dataset.role===b.dataset.role)) });
document.addEventListener('su:action',e=>{ const li=$(`#checklist [data-check="${e.detail.type}"]`); if(li) li.classList.add('done') });
$$('[data-jump]').forEach(a=>a.addEventListener('click',e=>{ e.preventDefault(); scrollToEl(play); setTimeout(()=>{ if(window.SU) SU.setRole(a.dataset.jump) },400) }));
$$('a[href^="#"]').forEach(a=>{ if(a.dataset.jump!==undefined) return; a.addEventListener('click',e=>{ const el=$(a.getAttribute('href')); if(!el) return; e.preventDefault(); scrollToEl(el) }) });
function scrollToEl(el){ const y=clamp(el.offsetTop,0,maxScroll()); if(reduced||!finePointer){window.scrollTo({top:y,behavior:reduced?'auto':'smooth'});return} target=y; if(!animating){animating=true;requestAnimationFrame(tick)} }

/* ---------- 6. frame ---------- */
function frame(){
  const y=window.scrollY; if(y===lastY) return; lastY=y;
  placeDevice(y); heroFade(y); storyFrame(y);
}
function layout(){ measure(); lastY=-1; frame(); }
let rt; addEventListener('resize',()=>{ clearTimeout(rt); rt=setTimeout(layout,120) });
addEventListener('load',()=>{ layout(); setTimeout(layout,300); setTimeout(layout,1200) });
if(document.fonts&&document.fonts.ready) document.fonts.ready.then(layout);
layout();
requestAnimationFrame(()=>{ device.classList.add('ready'); $('#hero').classList.add('in'); });
})();
