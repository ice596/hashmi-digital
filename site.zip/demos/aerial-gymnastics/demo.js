/* Hashmi Digital academy demo kit: free-trial booking prototype.
   Flow: programme -> age -> location -> day & time (demo data) -> details -> confirm -> WhatsApp opens to the academy's public number.
   Bookings are kept only in this browser (localStorage). Nothing is sent anywhere unless the visitor taps Send in WhatsApp. */
(function(){
'use strict';
const C=window.DEMO; if(!C) return;
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const WA_SVG='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.4.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.9 11.9 0 0 0 4.6 4c1.7.7 2.4.8 3.2.7.5-.1 1.5-.6 1.8-1.2.2-.6.2-1.1.1-1.2l-.5-.3z"/></svg>';
const DOW=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'], MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const STORE='hd-demo-'+C.key;
const load=()=>{try{return JSON.parse(localStorage.getItem(STORE))||[]}catch(e){return []}};
const save=a=>{try{localStorage.setItem(STORE,JSON.stringify(a))}catch(e){}};
const waUrl=(num,text)=>'https://wa.me/'+num+'?text='+encodeURIComponent(text);
const check=t=>{const li=$('#checklist [data-check="'+t+'"]'); if(li) li.classList.add('done')};

/* ---------- page chrome ---------- */
const io=new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){en.target.classList.add('in');io.unobserve(en.target)}}),{rootMargin:'0px 0px -8% 0px',threshold:.05});
$$('[data-reveal]').forEach(el=>io.observe(el));
const top=$('#top'); const onScroll=()=>top&&top.classList.toggle('solid',scrollY>40); addEventListener('scroll',onScroll,{passive:true}); onScroll();
const wrapEl=$('.device-wrap');
function fit(){ if(!wrapEl) return; const s=Math.min(1,wrapEl.clientWidth/414,(innerHeight-60)*.86/868); document.documentElement.style.setProperty('--s',s.toFixed(4)) }
fit(); addEventListener('resize',fit); addEventListener('load',fit);
// "Ask about camps" style enquiry links (not bookable: dates unknown)
$$('[data-enquire]').forEach(a=>{a.href=waUrl(C.wa,a.dataset.enquire+'\n\n(Sent from the Hashmi Digital demo page)');a.target='_blank';a.rel='noopener'});

/* ---------- app state ---------- */
const app=$('#app'); if(!app) return;
const STEPS=['Programme','Age','Location','Day & time','Your details','Review'];
let tab='book', step=0, b=fresh(), dayIdx=0, lastBooking=null;
function fresh(){return {program:null,age:null,extra:null,loc:null,area:null,date:null,time:null,parent:'',child:'',phone:'',note:''}}
const prog=()=>C.programs.find(p=>p.id===b.program);
const locsFor=p=>C.locations.filter(l=>!p||!p.venues||p.venues.includes(l.id));
const loc=()=>C.locations.find(l=>l.id===b.loc);
function days(){
  const p=prog(), l=loc(); const allowed=(p&&p.days)||(l&&l.days)||null; const out=[]; const d=new Date(); d.setHours(12,0,0,0);
  for(let i=1;out.length<10&&i<40;i++){const x=new Date(d); x.setDate(d.getDate()+i); if(!allowed||allowed.includes(x.getDay())) out.push(x)}
  return out;
}
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const fromIso=s=>{const [y,m,dd]=s.split('-').map(Number); return new Date(y,m-1,dd,12)};
const pretty=s=>{const d=fromIso(s); return DOW[d.getDay()]+' '+d.getDate()+' '+MON[d.getMonth()]};
const locLabel=x=>{const l=C.locations.find(q=>q.id===x.loc); return l?(l.short||l.name)+(x.area?', '+x.area:''):''};
const ageLabel=x=>(/^\d/.test(x.age)?'age ':'')+x.age+(C.agePhase&&C.agePhase(x)?' · '+C.agePhase(x):'');

function stepValid(){
  switch(step){
    case 0: return !!b.program;
    case 1: { const p=prog(); return !!b.age && (!p.extra||!!b.extra) }
    case 2: { const l=loc(); return !!l && (!l.areas||!!b.area) }
    case 3: return !!(b.date&&b.time);
    case 4: return b.parent.trim().length>1 && b.child.trim().length>0;
    default: return true;
  }
}

function render(){
  const n=load().length;
  app.innerHTML=`
  <div class="a-head"><img src="${C.logo}" alt="" ${C.logoBg?`style="background:${C.logoBg};padding:3px"`:''}><div class="t">${esc(C.appTitle)}<small>Free trial booking</small></div><span class="demo-tag">DEMO</span></div>
  <div class="a-tabs" role="tablist">
    <button data-tab="book" class="${tab==='book'?'on':''}">Book trial</button>
    <button data-tab="mine" class="${tab==='mine'?'on':''}">My trials${n?`<span class="n">${n}</span>`:''}</button>
    <button data-tab="dash" class="${tab==='dash'?'on':''}">Academy view</button>
  </div>
  <div class="a-body" id="aBody">${tab==='book'?bookView():tab==='mine'?mineView():dashView()}</div>
  ${tab==='book'?footView():''}`;
}

function bookView(){
  if(lastBooking) return doneView(lastBooking);
  const bar=`<div class="prog">${STEPS.map((_,i)=>`<i class="${i<=step?'on':''}"></i>`).join('')}</div><div class="a-step">Step ${step+1} of ${STEPS.length} · ${STEPS[step]}</div>`;
  const p=prog();
  if(step===0) return bar+`<h3 class="a-title">${esc(C.q.program)}</h3><p class="a-sub">${esc(C.q.programSub||'')}</p>
    <div class="opts">${C.programs.map(x=>`<button class="opt ${b.program===x.id?'on':''}" data-pick="program" data-v="${x.id}"><b>${esc(x.name)}</b><small>${esc(x.ageText)}${x.short?' · '+esc(x.short):''}</small></button>`).join('')}</div>
    ${C.notBookable?`<div class="note info">${C.notBookable}</div>`:''}`;
  if(step===1) return bar+`<h3 class="a-title">${esc(p.ageQ||C.q.age)}</h3><p class="a-sub">${esc(p.ageHelp||'')}</p>
    <div class="chips">${p.ages.map(a=>`<button class="chip ${b.age===a?'on':''}" data-pick="age" data-v="${esc(a)}">${esc(a)}</button>`).join('')}</div>
    ${b.age&&C.agePhase&&C.agePhase(b)?`<div class="note info">Pathway phase: <b>${esc(C.agePhase(b))}</b></div>`:''}
    ${p.extra?`<div class="sub-h">${esc(p.extra.label)}</div><div class="chips">${p.extra.options.map(o=>`<button class="chip ${b.extra===o?'on':''}" data-pick="extra" data-v="${esc(o)}">${esc(o)}</button>`).join('')}</div>`:''}`;
  if(step===2){ const ls=locsFor(p), l=loc();
    return bar+`<h3 class="a-title">${esc(C.q.location)}</h3><p class="a-sub">${esc(p.venueHelp||C.q.locationSub||'')}</p>
    <div class="opts">${ls.map(x=>`<button class="opt ${b.loc===x.id?'on':''}" data-pick="loc" data-v="${x.id}"><b>${esc(x.name)}</b><small>${esc(x.sub||'')}</small></button>`).join('')}</div>
    ${l&&l.areas?`<div class="sub-h">${esc(l.areaQ||'Area')}</div><div class="chips">${l.areas.map(a=>`<button class="chip ${b.area===a?'on':''}" data-pick="area" data-v="${esc(a)}">${esc(a)}</button>`).join('')}</div>`:''}`; }
  if(step===3){ const ds=days(); if(!b.date) {b.date=iso(ds[0]);} const sel=fromIso(b.date); const times=C.times(loc(),sel,p);
    return bar+`<h3 class="a-title">Pick a day and time</h3><p class="a-sub">${esc((p.dayNote)||(loc()&&loc().dayNote)||C.q.dayNote)}</p>
    <div class="day-row">${ds.map(d=>`<button class="day ${iso(d)===b.date?'on':''}" data-pick="date" data-v="${iso(d)}"><small>${DOW[d.getDay()]}</small><b>${d.getDate()}</b><small>${MON[d.getMonth()]}</small></button>`).join('')}</div>
    <div class="sub-h">Times · demo data</div>
    <div class="slots">${times.map(t=>`<button class="slot ${b.time===t?'on':''}" data-pick="time" data-v="${t}"><span class="dd">DEMO</span><b>${t}</b><small>${esc(p.slotLen||C.slotLen||'Free trial')}</small></button>`).join('')}</div>
    <div class="note">Sample slots for this demo. ${esc(C.q.timesTruth)}</div>`; }
  if(step===4) return bar+`<h3 class="a-title">Your details</h3><p class="a-sub">So the academy knows who is coming.</p>
    <label class="field"><span>Parent name</span><input data-f="parent" value="${esc(b.parent)}" autocomplete="name" placeholder="Your name"></label>
    <label class="field"><span>${esc(C.personLabel)} name</span><input data-f="child" value="${esc(b.child)}" placeholder="First name is fine"></label>
    <label class="field"><span>Your WhatsApp number <em>(optional)</em></span><input data-f="phone" value="${esc(b.phone)}" inputmode="tel" autocomplete="tel" placeholder="+971 5x xxx xxxx"></label>
    <label class="field"><span>${esc(C.noteLabel||'Anything the coach should know?')} <em>(optional)</em></span><textarea data-f="note" placeholder="${esc(C.notePlaceholder||'')}">${esc(b.note)}</textarea></label>
    <div class="note info">Demo: details stay in this browser. Nothing is sent until you tap Send in WhatsApp.</div>`;
  if(step===5) return bar+`<h3 class="a-title">Check and confirm</h3><p class="a-sub">Tap confirm and WhatsApp opens with this booking written out for ${esc(C.academy)}.</p>
    <div class="sum">${summaryRows(b)}</div>
    <div class="note">Fees: ${esc(C.feesShort)}</div>`;
  return '';
}
function summaryRows(x){
  const rows=[['Programme',(C.programs.find(p=>p.id===x.program)||{}).name],[C.personLabel,x.child+' · '+ageLabel(x)]];
  if(x.extra) rows.push([C.extraLabel||'Group',x.extra]);
  rows.push(['Location',locLabel(x)],['Slot',pretty(x.date)+', '+x.time+' (demo)'],['Parent',x.parent]);
  if(x.phone) rows.push(['WhatsApp',x.phone]);
  if(x.note) rows.push([C.noteShort||'Note',x.note]);
  return rows.map(r=>`<div><span>${esc(r[0])}</span><strong>${esc(r[1])}</strong></div>`).join('');
}
function footView(){
  if(lastBooking) return `<div class="a-foot"><button class="a-btn back" data-act="new" aria-label="Book another">+</button><a class="a-btn wa" href="${esc(lastBooking.url)}" target="_blank" rel="noopener" data-act="wa">${WA_SVG}Open WhatsApp again</a></div>`;
  return `<div class="a-foot">${step>0?'<button class="a-btn back" data-act="back" aria-label="Back">&larr;</button>':''}
    <button class="a-btn ${step===5?'wa':''}" data-act="next" ${stepValid()?'':'disabled'}>${step===5?WA_SVG+'Confirm &amp; open WhatsApp':'Continue'}</button></div>`;
}
function message(x){
  const p=C.programs.find(q=>q.id===x.program)||{};
  const lines=[C.msgIntro,'',
    'Parent: '+x.parent,
    C.personLabel+': '+x.child+' ('+ageLabel(x)+')',
    'Programme: '+p.name];
  if(x.extra) lines.push((C.extraLabel||'Group')+': '+x.extra);
  lines.push((C.locWord||'Location')+': '+locLabel(x),'Preferred day & time: '+pretty(x.date)+', '+x.time);
  if(x.phone) lines.push('My WhatsApp: '+x.phone);
  if(x.note) lines.push((C.noteShort||'Note')+': '+x.note);
  lines.push('','(Sent from the Hashmi Digital demo booking page)');
  return lines.join('\n');
}
function doneView(x){
  return `<div class="done-ic" aria-hidden="true"></div>
  <h3 class="a-title">Trial slot held</h3>
  <p class="a-sub">${esc(x.child)} · ${esc(pretty(x.date))}, ${esc(x.time)} at ${esc(locLabel(x))}. WhatsApp should have opened with the booking for ${esc(C.academy)}. If it didn't, tap the green button.</p>
  <div class="sum">${summaryRows(x)}</div>
  <div class="note">Demo: the slot is held only in this browser, and the time is sample data. ${esc(C.q.confirmTruth)}</div>
  <div class="sub-h">After the trial</div>
  <div class="note info">${C.afterTrial}</div>`;
}
function mineView(){
  const all=load(); if(!all.length) return `<div class="empty">No trials booked yet.<br>Book one in the first tab.</div>`;
  return `<h3 class="a-title">My trials</h3><p class="a-sub">Upcoming free trials booked from this phone. Demo data.</p>`+
    all.slice().reverse().map(x=>`<div class="bk"><div class="bk-h"><b>${esc(x.child)}</b><span class="st ${x.status!=='New'?'ok':''}">${esc(x.status==='New'?'Requested':x.status)}</span></div>
    <p><b>${esc(pretty(x.date))}, ${esc(x.time)}</b> (demo)</p><p>${esc((C.programs.find(p=>p.id===x.program)||{}).name)} · ${esc(locLabel(x))}</p>
    <div class="bk-acts"><a class="lnk" href="${esc(x.url)}" target="_blank" rel="noopener">Message the academy</a></div></div>`).join('');
}
function dashView(){
  const all=load();
  const head=`<h3 class="a-title">${esc(C.short)} · trials</h3><p class="a-sub">What the academy would see. Every booking arrives complete, with a slot, not as an open chat. Only bookings you made in this demo are shown.</p>`;
  if(!all.length) return head+`<div class="empty">No bookings yet.<br>Book a trial in the first tab and it lands here.</div>`;
  const conf=all.filter(x=>x.status!=='New').length;
  return head+`<div class="kpi"><div><b>${all.length}</b><small>trial requests (this demo)</small></div><div><b>${conf}</b><small>confirmed</small></div></div>`+
  all.slice().reverse().map(x=>`<div class="bk" data-id="${x.id}"><div class="bk-h"><b>${esc(x.child)} · ${esc(ageLabel(x))}</b><span class="st ${x.status!=='New'?'ok':''}">${esc(x.status)}</span></div>
    <p>${esc((C.programs.find(p=>p.id===x.program)||{}).name)}${x.extra?' · '+esc(x.extra):''}</p>
    <p><b>${esc(pretty(x.date))}, ${esc(x.time)}</b> · ${esc(locLabel(x))}</p>
    <p>Parent: ${esc(x.parent)}${x.phone?' · '+esc(x.phone):''}</p>${x.note?`<p>${esc(C.noteShort||'Note')}: ${esc(x.note)}</p>`:''}
    ${x.rec?`<p>${esc(C.recLabel)}: <b>${esc(x.rec)}</b></p>`:''}
    <div class="bk-acts">${x.status==='New'?'<button data-act="confirm">Confirm slot</button>':''}${x.status==='Confirmed'?'<button data-act="attended">Trial done</button>':''}
    ${x.status==='Trial done'&&C.recOptions?`<select data-act="rec" aria-label="${esc(C.recLabel)}"><option value="">${esc(C.recLabel)}…</option>${C.recOptions.map(o=>`<option ${x.rec===o?'selected':''}>${esc(o)}</option>`).join('')}</select>`:''}
    </div></div>`).join('')+`<div class="note info">${C.dashNote}</div>`;
}

/* ---------- events ---------- */
app.addEventListener('click',e=>{
  const t=e.target.closest('[data-tab]'); if(t){tab=t.dataset.tab; if(tab==='dash') check('dash'); render(); return}
  const pk=e.target.closest('[data-pick]');
  if(pk){ const k=pk.dataset.pick, v=pk.dataset.v;
    if(k==='program'){ if(b.program!==v){b=Object.assign(fresh(),{parent:b.parent,child:b.child,phone:b.phone,note:b.note})} b.program=v; check('program') }
    else if(k==='age'){ b.age=v }
    else if(k==='extra'){ b.extra=v }
    else if(k==='loc'){ if(b.loc!==v){b.area=null;b.date=null;b.time=null} b.loc=v }
    else if(k==='area'){ b.area=v }
    else if(k==='date'){ b.date=v; b.time=null }
    else if(k==='time'){ b.time=v; check('slot') }
    const body=$('#aBody'), y=body?body.scrollTop:0; render(); const nb=$('#aBody'); if(nb) nb.scrollTop=y; return }
  const a=e.target.closest('[data-act]'); if(!a) return; const act=a.dataset.act;
  if(act==='next'&&stepValid()){
    if(step<5){ step++; if(step===2){const ls=locsFor(prog()); if(ls.length===1&&!b.loc){b.loc=ls[0].id}} render(); return }
    // confirm
    const rec=Object.assign({},b,{id:Date.now().toString(36),status:'New',created:new Date().toISOString()}); rec.url=waUrl(C.wa,message(rec));
    const all=load(); all.push(rec); save(all); lastBooking=rec; check('confirm'); check('wa');
    window.open(rec.url,'_blank','noopener'); render(); return }
  if(act==='back'){ step=Math.max(0,step-1); render(); return }
  if(act==='new'){ lastBooking=null; step=0; b=fresh(); render(); return }
  if(act==='wa'){ check('wa'); return }
  const card=a.closest('[data-id]');
  if(card&&(act==='confirm'||act==='attended')){ const all=load(); const x=all.find(q=>q.id===card.dataset.id); if(x){x.status=act==='confirm'?'Confirmed':'Trial done'; save(all); render()} }
});
app.addEventListener('change',e=>{ const s=e.target.closest('select[data-act="rec"]'); if(!s) return; const card=s.closest('[data-id]'); const all=load(); const x=all.find(q=>q.id===card.dataset.id); if(x){x.rec=s.value; save(all); check('rec'); render()} });
app.addEventListener('input',e=>{ const f=e.target.dataset.f; if(!f) return; b[f]=e.target.value; const btn=app.querySelector('[data-act="next"]'); if(btn) btn.disabled=!stepValid() });
render();
})();
