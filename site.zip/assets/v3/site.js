/* Hashmi Digital v3 interactions. Motion (motion.dev) drives every animation; Lenis smooths the scroll. */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const desktop = matchMedia('(min-width: 861px)');
  const root = document.documentElement;

  // Clock in Abu Dhabi time
  const clock = $('#clock');
  const tick = () => { if (clock) clock.textContent = new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Dubai' }).format(new Date()); };
  tick(); setInterval(tick, 20000);
  const yr = $('#year'); if (yr) yr.textContent = new Date().getFullYear();

  const showAll = () => { root.classList.remove('js-motion'); $$('.pre').forEach(e => { e.style.opacity = 1; }); };
  const M = window.Motion;
  if (!M || reduce) {
    showAll();
    if (reduce) { const v = $('#heroVideo'); if (v) { v.pause(); v.removeAttribute('autoplay'); } }
    // still switch story videos by scroll position, without animation
    initStoryBasic();
    return;
  }
  const { animate, scroll, inView, stagger } = M;
  const ease = [0.16, 1, 0.3, 1];
  const elOf = (a) => (a instanceof Element ? a : a && a.target);
  window.__hdReady = true;

  // Smooth scroll
  let lenis = null;
  if (window.Lenis) {
    lenis = new window.Lenis({ duration: 1.1, easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)), smoothWheel: true });
    const raf = (t) => { lenis.raf(t); requestAnimationFrame(raf); };
    requestAnimationFrame(raf);
    $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
      const id = a.getAttribute('href'); const t = id.length > 1 && $(id);
      if (t) { e.preventDefault(); lenis.scrollTo(t, { offset: id === '#top' ? 0 : -10 }); }
    }));
  }

  /* ---------- hero film: 120 generated frames scrubbed by scroll ---------- */
  const hero = $('#hero'), cv = $('#heroCanvas'), poster = $('#heroPoster');
  const N = 120, frames = new Array(N);
  const src = i => `/assets/v3/seq/${String(i).padStart(3, '0')}.webp`;
  const load = i => new Promise(res => {
    if (frames[i]) return res();
    const im = new Image(); im.decoding = 'async';
    frames[i] = { im, ok: false };
    im.onload = () => { frames[i].ok = true; res(); }; im.onerror = () => res();
    im.src = src(i);
  });
  const firstPass = [0]; for (let i = 8; i < N; i += 8) firstPass.push(i);
  const ctx = cv && cv.getContext('2d');
  let cw = 0, ch = 0, drawn = -1, filmP = 0, filmCur = 0, heroOn = true;
  const size = () => {
    if (!cv) return;
    const d = Math.min(devicePixelRatio || 1, 1.5);
    cw = cv.width = Math.round(cv.clientWidth * d); ch = cv.height = Math.round(cv.clientHeight * d); drawn = -1;
  };
  const nearest = i => { for (let k = 0; k < N; k++) { const a = frames[i - k], b = frames[i + k]; if (a && a.ok) return a.im; if (b && b.ok) return b.im; } return null; };
  const draw = i => {
    if (!ctx || i === drawn) return;
    const im = nearest(i); if (!im) return;
    const s = Math.max(cw / im.naturalWidth, ch / im.naturalHeight), w = im.naturalWidth * s, h = im.naturalHeight * s;
    ctx.drawImage(im, (cw - w) / 2, (ch - h) * 0.5, w, h); drawn = frames[i] && frames[i].ok ? i : -1;
    if (poster && poster.style.opacity !== '0') poster.style.opacity = '0';
  };
  size(); addEventListener('resize', size);
  const filmLoop = (t) => {
    if (heroOn) {
      const breathe = (Math.sin(t / 1000 * 0.7) * 0.5 + 0.5) * 7 * (1 - Math.min(1, filmP * 3));
      const target = filmP * (N - 1) + breathe;
      filmCur += (target - filmCur) * 0.12;
      draw(Math.max(0, Math.min(N - 1, Math.round(filmCur))));
    }
    requestAnimationFrame(filmLoop);
  };
  inView(hero, () => { heroOn = true; return () => { heroOn = false; }; }, { margin: '0px 0px 0px 0px' });

  const act1 = $('#act1'), act2Lines = $$('#act2 .big > span');
  const band = (p, a, b) => Math.max(0, Math.min(1, (p - a) / (b - a)));
  scroll(p => {
    filmP = p;
    const o1 = 1 - band(p, 0.14, 0.36);
    act1.style.opacity = o1; act1.style.transform = `translateY(${-90 * band(p, 0.1, 0.4)}px)`;
    act1.style.pointerEvents = o1 < 0.3 ? 'none' : '';
    const out = band(p, 0.86, 0.99);
    if (cv) cv.style.opacity = 1 - 0.55 * band(p, 0.9, 1);
    act2Lines.forEach((el, i) => {
      const inn = band(p, 0.3 + i * 0.1, 0.44 + i * 0.1);
      el.style.opacity = inn * (1 - out);
      el.style.transform = `translateY(${(1 - inn) * 60 - out * 50}px) scale(${0.96 + inn * 0.04})`;
      el.style.filter = `blur(${(1 - inn) * 10}px)`;
    });
  }, { target: hero, offset: ['start start', 'end end'] });

  /* ---------- intro: counter tied to the first frames loading ---------- */
  const intro = $('#intro'), introNum = $('#introNum'), introBar = $('#introBar');
  const runHeroIntro = () => {
    animate('#heroTitle .line > span', { y: ['110%', '0%'] }, { duration: 1.1, delay: stagger(0.09, { startDelay: 0.05 }), ease });
    animate('.hero [data-fade]', { opacity: [0, 1], y: [18, 0] }, { duration: 0.9, delay: stagger(0.1, { startDelay: 0.4 }), ease });
    animate('.hero .chip', { opacity: [0, 1], x: [-14, 0] }, { duration: 0.7, delay: stagger(0.06, { startDelay: 0.65 }), ease });
    animate('.nav .pill', { opacity: [0, 1], y: [-12, 0] }, { duration: 0.7, delay: stagger(0.05, { startDelay: 0.1 }), ease });
  };
  let shown = 0, loaded = 0; const t0 = performance.now();
  const setCount = v => { shown = v; if (introNum) introNum.textContent = Math.round(v); if (introBar) introBar.style.transform = `scaleX(${v / 100})`; };
  const seen = (() => { try { return sessionStorage.getItem('hd-intro') === '1'; } catch (e) { return false; } })();
  const finishIntro = () => {
    try { sessionStorage.setItem('hd-intro', '1'); } catch (e) {}
    requestAnimationFrame(filmLoop);
    if (!intro) { runHeroIntro(); return; }
    animate(intro, { clipPath: ['inset(0 0 0% 0)', 'inset(0 0 100% 0)'] }, { duration: 0.9, ease: [0.76, 0, 0.24, 1] }).then(() => intro.remove());
    setTimeout(runHeroIntro, 380);
  };
  load(0).then(() => draw(0));
  const firstLoad = Promise.all(firstPass.map(i => load(i).then(() => { loaded++; })));
  if (seen || !intro) { if (intro) intro.remove(); finishIntro(); }
  else {
    animate('.intro-mark', { y: ['35%', '0%'], opacity: [0, 1] }, { duration: 0.8, ease });
    const counter = () => {
      const el = performance.now() - t0;
      const goal = Math.min(100, Math.max(loaded / firstPass.length * 100, 0) * 0.7 + Math.min(1, el / 1300) * 30);
      setCount(shown + (goal - shown) * 0.18);
      if (shown > 99.4 || el > 2600) { setCount(100); finishIntro(); } else requestAnimationFrame(counter);
    };
    requestAnimationFrame(counter);
  }
  firstLoad.then(() => { for (let i = 0; i < N; i++) load(i); });

  /* ---------- nav hides on the way down ---------- */
  const nav = $('#nav'); let navHidden = false, lastY = 0;
  scroll((_, info) => {
    const y = info.y.current; const down = y > lastY + 2, up = y < lastY - 2; lastY = y;
    if (y > 160 && down && !navHidden) { navHidden = true; animate(nav, { y: '-120%' }, { duration: 0.45, ease }); }
    else if ((up || y < 160) && navHidden) { navHidden = false; animate(nav, { y: '0%' }, { duration: 0.45, ease }); }
  });

  /* ---------- marquee ---------- */
  const mq = $('#marquee');
  if (mq) animate(mq, { x: ['0%', '-50%'] }, { duration: 38, repeat: Infinity, ease: 'linear' });

  /* ---------- story ---------- */
  initStory();

  /* ---------- reveals ---------- */
  const reveal = (sel, from = { opacity: [0, 1], y: [40, 0] }, opts = {}) => $$(sel).forEach(el => {
    el.style.opacity = 0;
    inView(el, () => { animate(el, from, { duration: 1, ease, ...opts }); }, { amount: 0.25 });
  });
  reveal('.sec-head h2');
  reveal('.sec-head p', { opacity: [0, 1], y: [20, 0] }, { delay: 0.15 });
  reveal('.eyebrow', { opacity: [0, 1], x: [-10, 0] });
  reveal('.founder', { opacity: [0, 1], y: [30, 0] });
  reveal('.wcard .meta', { opacity: [0, 1] });

  // Receipts slide in from their sides, then the numbers count
  $$('.receipt').forEach(r => {
    const dir = Number(r.dataset.slide || 0);
    r.style.opacity = 0;
    inView(r, () => { animate(r, { opacity: [0, 1], x: [dir * 60, 0], rotate: [dir * 2, 0] }, { type: 'spring', stiffness: 120, damping: 18 }); }, { amount: 0.3 });
  });
  $$('[data-count]').forEach(el => {
    const to = parseFloat(el.dataset.count), dec = Number(el.dataset.dec || 0);
    el.textContent = (0).toFixed(dec);
    inView(el, () => { animate(0, to, { duration: 1.4, ease, onUpdate: v => { el.textContent = v.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec }); } }); }, { amount: 0.6 });
  });

  /* ---------- services: stacking cards + chat + videos ---------- */
  const cards = $$('#stack .svc');
  const stackLinks = [];
  const setupStack = () => {
    stackLinks.splice(0).forEach(stop => stop && stop());
    if (!desktop.matches) { cards.forEach(c => { c.style.transform = ''; c.style.filter = ''; }); return; }
    cards.forEach((card, i) => {
      const next = cards[i + 1]; if (!next) return;
      stackLinks.push(scroll(animate(card, { scale: [1, 0.92], filter: ['brightness(1)', 'brightness(.82)'] }, { ease: 'linear' }), { target: next, offset: ['start end', 'start 90px'] }));
    });
  };
  setupStack(); desktop.addEventListener('change', setupStack);

  const chat = $('#chat');
  if (chat) {
    const bubs = $$('.bub', chat), typing = $('.typing', chat);
    let running = false, timer = null;
    const play = async () => {
      if (running) return; running = true;
      bubs.forEach(b => { b.style.opacity = 0; b.style.transform = 'translateY(8px) scale(.98)'; }); typing.style.opacity = 0;
      const show = (el) => animate(el, { opacity: [0, 1], y: [8, 0], scale: [0.98, 1] }, { type: 'spring', stiffness: 260, damping: 22 });
      const wait = (ms) => new Promise(r => { timer = setTimeout(r, ms); });
      await wait(300); show(bubs[0]);
      await wait(700); typing.style.order = 1; animate(typing, { opacity: 1 }, { duration: 0.2 });
      await wait(1200); animate(typing, { opacity: 0 }, { duration: 0.15 }); show(bubs[1]);
      await wait(1300); show(bubs[2]);
      await wait(800); animate(typing, { opacity: 1 }, { duration: 0.2 });
      await wait(1100); animate(typing, { opacity: 0 }, { duration: 0.15 }); show(bubs[3]);
      await wait(4200); running = false;
    };
    inView(chat, () => { play(); const iv = setInterval(play, 10500); return () => { clearInterval(iv); clearTimeout(timer); running = false; }; }, { amount: 0.4 });
  }

  $$('video[data-autoplay]').forEach(v => {
    inView(v, () => { v.play().catch(() => {}); return () => v.pause(); }, { amount: 0.1 });
  });

  /* ---------- statement: words light up as you read ---------- */
  const st = $('#statement');
  if (st) {
    const words = [];
    const split = (node, hl) => {
      [...node.childNodes].forEach(n => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach(part => {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
            const s = document.createElement('span'); s.className = 'w' + (hl ? ' hl' : ''); s.textContent = part; frag.appendChild(s); words.push(s);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) { split(n, hl || n.classList.contains('hl')); }
      });
    };
    split(st, false);
    const N = words.length;
    scroll(p => {
      const lit = p * (N + 4);
      for (let i = 0; i < N; i++) { const o = Math.min(1, Math.max(0.14, (lit - i) / 4)); words[i].style.opacity = o; }
    }, { target: st, offset: ['start 0.85', 'end 0.45'] });
  }

  /* ---------- work rail: vertical scroll drives a horizontal row ---------- */
  const work = $('#work'), track = $('#railTrack'), bar = $('#workBar'), wc = $('#workCount');
  if (work && track) {
    const n = track.children.length; let dist = 0;
    const measure = () => { dist = Math.max(0, track.scrollWidth - innerWidth + parseFloat(getComputedStyle(track).paddingLeft || 0)); };
    measure(); addEventListener('resize', measure);
    scroll(p => {
      track.style.transform = `translate3d(${-p * dist}px,0,0)`;
      if (bar) bar.style.transform = `scaleX(${p})`;
      if (wc) wc.textContent = String(1 + Math.round(p * (n - 1))).padStart(2, '0') + ' / ' + String(n).padStart(2, '0');
    }, { target: work });
    $$('.wcard .shot img').forEach(img => { scroll(animate(img, { x: ['-4%', '4%'], scale: [1.1, 1.1] }, { ease: 'linear' }), { target: work }); });
  }

  /* ---------- process ---------- */
  const grid = $('#processGrid');
  if (grid) {
    scroll(animate('#procLine', { scaleX: [0, 1] }, { ease: 'linear' }), { target: grid, offset: ['start 0.85', 'end 0.55'] });
    $$('.pstep', grid).forEach(s => { s.style.opacity = 0; });
    inView(grid, () => { animate($$('.pstep', grid), { opacity: [0, 1], y: [30, 0] }, { duration: 0.9, delay: stagger(0.12), ease }); }, { amount: 0.25 });
  }

  /* ---------- contact + footer ---------- */
  const ct = $('#contactTitle');
  if (ct) { const spans = $$('.line > span', ct); spans.forEach(s => { s.style.transform = 'translateY(110%)'; }); inView(ct, () => { animate(spans, { y: ['110%', '0%'] }, { duration: 1.1, delay: stagger(0.09), ease }); }, { amount: 0.4 }); }
  const form = $('form.form');
  if (form) { form.style.opacity = 0; inView(form, () => { animate(form, { opacity: [0, 1], y: [40, 0] }, { duration: 1, ease, delay: 0.15 }); }, { amount: 0.2 }); }
  const giant = $('#giant span');
  if (giant) scroll(animate(giant, { y: ['70%', '0%'] }, { ease: 'linear' }), { target: $('#giant'), offset: ['start end', 'end end'] });

  /* ---------- magnetic buttons ---------- */
  if (matchMedia('(hover: hover)').matches) {
    $$('.magnet').forEach(el => {
      el.addEventListener('pointermove', e => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left - r.width / 2) * 0.22, y = (e.clientY - r.top - r.height / 2) * 0.3;
        animate(el, { x, y }, { type: 'spring', stiffness: 320, damping: 22, mass: 0.6 });
      });
      el.addEventListener('pointerleave', () => animate(el, { x: 0, y: 0 }, { type: 'spring', stiffness: 260, damping: 18 }));
    });
  }

  /* ---------- clip-path reveals on imagery ---------- */
  $$('.wcard .shot, [data-clip]').forEach(el => {
    el.style.clipPath = 'inset(100% 0 0 0 round 18px)';
    inView(el.parentElement || el, () => { animate(el, { clipPath: ['inset(100% 0% 0% 0% round 18px)', 'inset(0% 0% 0% 0% round 18px)'] }, { duration: 1.2, ease: [0.76, 0, 0.24, 1] }); }, { amount: 0.2 });
  });

  /* ---------- custom cursor (mouse only) ---------- */
  const cur = $('#cursor'), curLabel = $('#cursorLabel');
  if (cur && matchMedia('(hover: hover) and (pointer: fine)').matches) {
    let mx = -100, my = -100, cx = -100, cy = -100, big = false, sz = 12;
    addEventListener('pointermove', e => { mx = e.clientX; my = e.clientY; }, { passive: true });
    document.addEventListener('pointerleave', () => { mx = my = -100; });
    const loop = () => {
      cx += (mx - cx) * 0.2; cy += (my - cy) * 0.2;
      cur.style.transform = `translate3d(${cx}px,${cy}px,0)`;
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
    const grow = (label) => {
      big = !!label; if (curLabel) curLabel.textContent = label || '';
      cur.classList.toggle('big', big);
      animate(cur, { width: big ? 92 : 12, height: big ? 92 : 12, marginLeft: big ? -46 : -6, marginTop: big ? -46 : -6 }, { type: 'spring', stiffness: 380, damping: 28 });
    };
    document.addEventListener('pointerover', e => {
      const t = e.target.closest('[data-cursor]');
      if (t) grow(t.dataset.cursor);
      else if (big) grow('');
      if (!t) { const a = e.target.closest('a,button,input,select,textarea,label'); cur.style.opacity = a ? '0.35' : '1'; }
    });
  }

  // Everything initialised: drop the safety net
  root.classList.add('motion-ready');

  /* ===== story implementation ===== */
  function initStory() {
    const story = $('#how'); if (!story) return;
    const steps = $$('.step', story), vids = $$('.screen video', story), phone = $('#storyPhone'), count = $('#storyCount'), fill = $('#railFill');
    let cur = -1, visible = false;
    const setStep = (i) => {
      if (i === cur) return; cur = i;
      steps.forEach((s, k) => s.classList.toggle('on', k === i));
      vids.forEach((v, k) => {
        const on = k === i; v.classList.toggle('on', on);
        if (on) { try { v.currentTime = 0; } catch (e) {} if (visible) v.play().catch(() => {}); } else v.pause();
      });
      if (count) count.textContent = String(i + 1).padStart(2, '0') + ' / 04';
      if (phone) animate(phone, { scale: [0.96, 1], rotate: [i % 2 ? -1.5 : 1.5, 0] }, { type: 'spring', stiffness: 200, damping: 16 });
    };
    setStep(0);
    scroll(p => {
      const i = Math.min(steps.length - 1, Math.max(0, Math.floor(p * steps.length * 0.999)));
      setStep(i);
      if (fill) fill.style.transform = `scaleY(${p})`;
    }, { target: story });
    if (phone) scroll(animate(phone, { y: [180, 0], rotateX: [18, 0], scale: [0.86, 1] }, { ease: 'linear' }), { target: story, offset: ['start end', 'start start'] });
    inView(story, () => { visible = true; const v = vids[cur]; if (v) v.play().catch(() => {}); return () => { visible = false; vids.forEach(v => v.pause()); }; }, { amount: 0.2 });
  }

  function initStoryBasic() {
    const story = document.getElementById('how'); if (!story) return;
    const steps = [...story.querySelectorAll('.step')], vids = [...story.querySelectorAll('.screen video')];
    const upd = () => {
      const r = story.getBoundingClientRect(); const total = r.height - innerHeight;
      const p = total > 0 ? Math.min(1, Math.max(0, -r.top / total)) : 0;
      const i = Math.min(steps.length - 1, Math.floor(p * steps.length * 0.999));
      steps.forEach((s, k) => s.classList.toggle('on', k === i || reduce));
      vids.forEach((v, k) => v.classList.toggle('on', k === i));
    };
    addEventListener('scroll', upd, { passive: true }); upd();
  }
})();
