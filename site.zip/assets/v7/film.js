/* Hashmi Digital — scroll-film hero engine (canvas frame scrub + WebGL dust) */
(function () {
  'use strict';
  var film = document.querySelector('.film');
  if (!film) { window.__ready = true; return; }
  var reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced) { window.__ready = true; return; }

  var JUMP = new URLSearchParams(location.search).get('jump');
  if (JUMP !== null) { history.scrollRestoration = 'manual'; }

  var mobile = innerWidth <= 760;
  var N = mobile ? 61 : 121;
  var DIR = mobile ? '/assets/hero/seqm/' : '/assets/hero/seq/';
  var AHEAD = mobile ? 26 : 48, KEEP = mobile ? 34 : 60;
  film.style.setProperty('--filmH', mobile ? '240svh' : '340svh');
  film.classList.add('on');

  var stage = film.querySelector('.film-stage');
  var canvas = film.querySelector('.film-canvas');
  var ctx = canvas.getContext('2d');
  var veil = film.querySelector('.film-veil');
  var copy1 = film.querySelector('[data-beat="hero"]');
  var copy2 = film.querySelector('[data-beat="mid"]');

  /* ---- frame loading: concurrency pump ---- */
  var images = new Array(N), loaded = 0, inflight = 0, next = 0, CONC = 10;
  function src(i) { return DIR + 'f_' + String(i + 1).padStart(3, '0') + '.webp'; }
  function pump() {
    while (inflight < CONC && next < N) {
      (function (i) {
        inflight++; next++;
        var im = new Image();
        im.decoding = 'async';
        im.fetchPriority = 'low';
        im.onload = function () { images[i] = im; loaded++; inflight--; pump(); };
        im.onerror = function () { inflight--; pump(); };
        im.src = src(i);
      })(next);
    }
  }

  /* ---- ImageBitmap sliding window ---- */
  var bitmaps = new Map(), decoding = new Set(), bmpCenter = -999, displayed = -1;
  function ensureBitmaps(center) {
    if (Math.abs(center - bmpCenter) < 3 && bitmaps.size) return;
    bmpCenter = center;
    var lo = Math.max(0, center - 8), hi = Math.min(N - 1, center + AHEAD);
    for (var i = lo; i <= hi; i++) {
      if (bitmaps.has(i) || decoding.has(i) || !images[i]) continue;
      decoding.add(i);
      (function (i) {
        createImageBitmap(images[i]).then(function (b) {
          decoding.delete(i);
          if (Math.abs(i - bmpCenter) > KEEP) { b.close(); return; }
          bitmaps.set(i, b);
          if (i === displayed) draw(i, true);
        }).catch(function () { decoding.delete(i); });
      })(i);
    }
    bitmaps.forEach(function (b, k) {
      if (k < center - KEEP || k > center + KEEP) { b.close(); bitmaps.delete(k); }
    });
  }
  function nearest(idx) {
    if (bitmaps.has(idx)) return bitmaps.get(idx);
    for (var d = 1; d < N; d++) {
      if (bitmaps.has(idx - d)) return bitmaps.get(idx - d);
      if (bitmaps.has(idx + d)) return bitmaps.get(idx + d);
    }
    return null;
  }

  /* ---- canvas ---- */
  function size() {
    canvas.width = stage.clientWidth;      /* DPR capped at 1: source is 1440/480 */
    canvas.height = stage.clientHeight;
    displayed = -1;
  }
  size();
  var MAX_CROP = 0.52; /* centred-subject footage: cover is right here */
  function draw(idx, force) {
    if (idx === displayed && !force) return;
    var bm = nearest(idx);
    if (!bm) return;
    var cw = canvas.width, ch = canvas.height;
    var sC = Math.max(cw / bm.width, ch / bm.height);
    var crop = 1 - Math.min(cw / (bm.width * sC), ch / (bm.height * sC));
    var s = crop > MAX_CROP ? Math.min(cw / bm.width, ch / bm.height) : sC;
    var w = bm.width * s, h = bm.height * s;
    if (crop > MAX_CROP) { ctx.fillStyle = '#0B0908'; ctx.fillRect(0, 0, cw, ch); }
    ctx.drawImage(bm, (cw - w) / 2, (ch - h) / 2, w, h);
    displayed = idx;
    if (!film.classList.contains('live')) film.classList.add('live');
  }

  /* ---- beats ---- */
  function env(p, a, peak, b) {
    if (p < a || p > b) return 0;
    if (p < peak) return (p - a) / Math.max(1e-4, peak - a);
    return 1 - (p - peak) / Math.max(1e-4, b - peak);
  }
  function overlays(p) {
    var a1 = p < 0.03 ? 1 : Math.max(0, 1 - (p - 0.03) / 0.17);
    copy1.style.opacity = a1;
    copy1.style.transform = (mobile ? '' : 'translateY(' + (-50 + (1 - a1) * -4) + '%)');
    copy1.style.pointerEvents = a1 > 0.5 ? '' : 'none';
    copy1.style.visibility = a1 > 0.01 ? '' : 'hidden';
    var a2 = env(p, 0.34, 0.5, 0.68);
    copy2.style.opacity = a2;
    copy2.style.visibility = a2 > 0.01 ? '' : 'hidden';
    veil.style.opacity = Math.max(0, (p - 0.9) / 0.1);
    film.classList.toggle('done', p > 0.04);
  }

  /* ---- tick ---- */
  var cur = 0, running = true;
  function progress() {
    var r = film.getBoundingClientRect();
    var span = r.height - innerHeight;
    return span > 0 ? Math.max(0, Math.min(1, -r.top / span)) : 0;
  }
  function tick() {
    if (running) {
      var p = progress();
      var target = p * (N - 1);
      cur += (target - cur) * 0.14;
      if (Math.abs(target - cur) < 0.02) cur = target;
      var idx = Math.round(cur);
      ensureBitmaps(idx);
      draw(idx);
      overlays(p);
      dustTick(p);
    }
    requestAnimationFrame(tick);
  }

  /* ---- WebGL dust in the beam (hand-rolled, ~1KB) ---- */
  var dustTick = function () {};
  (function () {
    var dc = film.querySelector('.film-dust');
    var gl = dc.getContext('webgl', { alpha: true, antialias: false, powerPreference: 'low-power' });
    if (!gl) { dc.remove(); return; }
    var PN = mobile ? 60 : 130;
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return o; }
    var pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER,
      'attribute vec4 a;uniform float t;uniform vec2 res;varying float v;' +
      'void main(){float ph=a.z;float sp=a.w;' +
      'float x=a.x+sin(t*0.12*sp+ph)*0.05+t*0.008*sp;' +
      'float y=a.y+cos(t*0.09*sp+ph*1.7)*0.04-t*0.012*sp;' +
      'x=mod(x,1.4)-0.2;y=mod(y,1.2)-0.1;' +
      'v=0.5+0.5*sin(t*0.8*sp+ph*3.0);' +
      'gl_Position=vec4(x*2.0-1.0,1.0-y*2.0,0.,1.);' +
      'gl_PointSize=(1.5+sp*2.6)*(res.x>900.?1.3:1.0);}'));
    gl.attachShader(pr, sh(gl.FRAGMENT_SHADER,
      'precision mediump float;varying float v;uniform float ga;' +
      'void main(){vec2 d=gl_PointCoord-0.5;float a=smoothstep(0.5,0.0,length(d));' +
      'gl_FragColor=vec4(0.91,0.75,0.54,a*v*0.5*ga);}'));
    gl.linkProgram(pr); gl.useProgram(pr);
    var data = new Float32Array(PN * 4);
    for (var i = 0; i < PN; i++) {
      data[i * 4] = Math.random();           /* x */
      data[i * 4 + 1] = Math.random();       /* y */
      data[i * 4 + 2] = Math.random() * 6.28;/* phase */
      data[i * 4 + 3] = 0.3 + Math.random(); /* speed/depth */
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(pr, 'a');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, 0, 0);
    var uT = gl.getUniformLocation(pr, 't'), uR = gl.getUniformLocation(pr, 'res'), uG = gl.getUniformLocation(pr, 'ga');
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    function dsize() { dc.width = stage.clientWidth; dc.height = stage.clientHeight; gl.viewport(0, 0, dc.width, dc.height); }
    dsize();
    addEventListener('resize', dsize);
    var t0 = performance.now();
    dustTick = function (p) {
      var ga = Math.max(0, 1 - p * 1.6);           /* fade dust out over first ~60% */
      if (ga <= 0) { gl.clear(gl.COLOR_BUFFER_BIT); return; }
      gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.uniform1f(uT, (performance.now() - t0) / 1000);
      gl.uniform2f(uR, dc.width, dc.height);
      gl.uniform1f(uG, ga);
      gl.drawArrays(gl.POINTS, 0, PN);
    };
  })();

  /* ---- pause offscreen ---- */
  new IntersectionObserver(function (es) {
    running = es[0].isIntersecting && !document.hidden;
  }).observe(stage);
  document.addEventListener('visibilitychange', function () { running = !document.hidden; });
  addEventListener('resize', function () { size(); displayed = -1; });

  /* ---- boot: never compete with the poster LCP ---- */
  function startPump() { setTimeout(pump, 350); }
  if (document.readyState === 'complete') startPump();
  else addEventListener('load', startPump);
  var boot = setInterval(function () {
    if (images[0]) {
      clearInterval(boot);
      ensureBitmaps(0);
      if (JUMP !== null) {
        scrollTo(0, +JUMP || 0);
        setTimeout(function () { cur = progress() * (N - 1); window.__ready = true; }, 600);
      } else { window.__ready = true; }
    }
  }, 60);
  setTimeout(function () { window.__ready = true; }, 6000); /* never gate forever */
  requestAnimationFrame(tick);
})();
