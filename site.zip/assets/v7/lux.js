/* Hashmi Digital lux layer v4: IO reveals up front; GSAP (gsap-core +
   gsap-scrolltrigger patterns) loads after window load for scroll moments,
   so no animation library sits in the critical path. */
(function(){
  var RM=matchMedia('(prefers-reduced-motion: reduce)').matches||/[?&]nomo/.test(location.search);

  /* mobile menu */
  var mbtn=document.querySelector('.mnav-btn'),mnav=document.getElementById('mnav');
  if(mbtn&&mnav){
    mbtn.addEventListener('click',function(){
      var open=mnav.hidden;
      mnav.hidden=!open;
      mbtn.classList.toggle('on',open);
      mbtn.setAttribute('aria-expanded',open?'true':'false');
      document.body.style.overflow=open?'hidden':'';
      if(open&&window.gsap&&!RM){
        gsap.from('#mnav a, #mnav .mnav-note',{opacity:0,y:18,duration:.5,stagger:.06,ease:'power2.out',clearProps:'all'});
      }
    });
    mnav.addEventListener('click',function(e){
      if(e.target.tagName==='A'){mnav.hidden=true;mbtn.classList.remove('on');mbtn.setAttribute('aria-expanded','false');document.body.style.overflow=''}
    });
  }

  /* reduced motion: show the chat demo's final state instead of animating */
  if(RM){
    document.querySelectorAll('.bot-body .m').forEach(function(m){
      if(m.classList.contains('typing'))return;
      m.classList.add('show','vis');
    });
  }

  /* hero loops: start after first paint settles; poster images carry the LCP */
  if(!RM){
    setTimeout(function(){
      document.querySelectorAll('[data-heroloop]').forEach(function(v){
        if(getComputedStyle(v).display!=='none'){v.play().then(function(){var o=v.closest('.hero-obj');if(o)o.classList.add('playing')}).catch(function(){})}
      });
    },250);
  }

  /* reveals: IntersectionObserver, visible-at-load shows at once */
  var els=[].slice.call(document.querySelectorAll('.rv'));
  var hero=function(el){return !!el.closest('.hero-lx')};
  var below=els.filter(function(e){return !hero(e)});
  if(RM||!('IntersectionObserver' in window)){
    els.forEach(function(e){e.classList.add('in')});
  }else{
    below.forEach(function(e){
      if(e.getBoundingClientRect().top<innerHeight*0.9)e.classList.add('in');
    });
    var io=new IntersectionObserver(function(entries){
      entries.forEach(function(en){if(en.isIntersecting){en.target.classList.add('in');io.unobserve(en.target)}});
    },{threshold:0,rootMargin:'0px 0px 320px 0px'});
    below.forEach(function(e){if(!e.classList.contains('in'))io.observe(e)});
  }

  /* GSAP scroll moments, loaded after the page is done */
  function initGsap(){
    if(!window.gsap||!window.ScrollTrigger)return;
    gsap.registerPlugin(ScrollTrigger);

    /* Lenis smooth scroll, desktop pointers only, synced with ScrollTrigger */
    if(matchMedia('(min-width: 1021px) and (pointer: fine)').matches&&!new URLSearchParams(location.search).has('jump')){
      loadScript('/assets/vendor/lenis.min.js',function(){
        if(!window.Lenis)return;
        var lenis=window.__lenis=new Lenis({lerp:0.09,smoothWheel:true});
        lenis.on('scroll',ScrollTrigger.update);
        gsap.ticker.add(function(t){lenis.raf(t*1000)});
        gsap.ticker.lagSmoothing(0);
      });
    }

    /* story band: full-bleed photo to ad, pinned scrub on desktop */
    var pab=document.querySelector('.pab');
    if(pab&&matchMedia('(min-width: 1021px)').matches){
      var pabAfter=pab.querySelector('.pab-after'),pabSweep=pab.querySelector('.pab-sweep');
      ScrollTrigger.create({
        trigger:pab,start:'top top',end:'+=120%',pin:true,scrub:true,
        onUpdate:function(st){
          var p=st.progress;
          var f=Math.max(0,Math.min(1,(p-0.12)/0.5));
          gsap.set(pabAfter,{opacity:f});
          pabSweep.style.transform='translateX('+(-140+f*480)+'%) skewX(-14deg)';
          pab.classList.toggle('done',p>0.62);
        }
      });
      pab.setAttribute('data-pab-wired','1');
    }

    var sig=document.querySelector('.sig-word');
    if(sig){
      gsap.fromTo(sig,{opacity:.1,scale:.94},{
        opacity:.92,scale:1,ease:'none',
        scrollTrigger:{trigger:'.sig-band',start:'top 90%',end:'center 55%',scrub:true}
      });
    }
    gsap.matchMedia().add('(min-width: 1021px)',function(){
      document.querySelectorAll('.bd>.bd-img').forEach(function(img){
        gsap.fromTo(img,{yPercent:-5},{yPercent:5,ease:'none',
          scrollTrigger:{trigger:img.parentElement,start:'top bottom',end:'bottom top',scrub:true}});
      });
    });
  }
  function loadScript(src,cb){var sc=document.createElement('script');sc.src=src;sc.onload=cb;document.head.appendChild(sc)}
  if(!RM&&(document.querySelector('.sig-word')||document.querySelector('.bd'))){
    var boot=function(){
      if(!document.getElementById('wa-float'))loadScript('/assets/v7/wa.js?v=16',function(){});
      loadScript('/assets/vendor/gsap/gsap.min.js',function(){
        loadScript('/assets/vendor/gsap/ScrollTrigger.min.js',initGsap);
      });
    };
    if(document.readyState==='complete'){boot()}else{addEventListener('load',boot)}
  }

  /* story band: mobile and fallback crossfade once in view */
  var pabM=document.querySelector('.pab');
  if(pabM&&!RM){
    setTimeout(function(){
      if(pabM.getAttribute('data-pab-wired'))return;
      if('IntersectionObserver' in window){
        var pio=new IntersectionObserver(function(es){
          es.forEach(function(e){
            if(e.isIntersecting){
              pio.disconnect();
              setTimeout(function(){
                pabM.classList.add('auto');
                setTimeout(function(){pabM.classList.add('done')},2200);
              },500);
            }
          });
        },{threshold:.45});
        pio.observe(pabM);
      }else{pabM.classList.add('auto','done')}
    },1400);
  }

  /* numbers count up once in view */
  var cnts=document.querySelectorAll('[data-cnt]');
  if(cnts.length&&!RM&&'IntersectionObserver' in window){
    var cio=new IntersectionObserver(function(es){
      es.forEach(function(e){
        if(!e.isIntersecting)return;
        var el=e.target;cio.unobserve(el);
        var T=+el.getAttribute('data-cnt'),t0=null;
        function stp(ts){
          if(!t0)t0=ts;
          var k=Math.min(1,(ts-t0)/900);
          el.textContent=Math.round(T*(0.25+0.75*k*k)).toLocaleString('en-US');
          if(k<1)requestAnimationFrame(stp);else el.textContent=T.toLocaleString('en-US');
        }
        requestAnimationFrame(stp);
      });
    },{threshold:.6});
    cnts.forEach(function(e){cio.observe(e)});
  }

  /* ad cards: tap to play with sound, one at a time */

  var cards=[].slice.call(document.querySelectorAll('.adc'));
  function stopAll(except){
    cards.forEach(function(c){
      var v=c.querySelector('video');
      if(v&&v!==except){v.pause();c.classList.remove('playing')}
    });
  }
  if('IntersectionObserver' in window&&cards.length){
    var vio=new IntersectionObserver(function(es){
      es.forEach(function(e){
        if(!e.isIntersecting){
          var vv=e.target.querySelector('video');
          if(vv&&!vv.paused){vv.pause();e.target.classList.remove('playing')}
        }
      });
    },{threshold:.1});
    cards.forEach(function(c){vio.observe(c)});
  }
  cards.forEach(function(c){
    var v=c.querySelector('video'),p=c.querySelector('.play');
    if(!v||!p)return;
    p.addEventListener('click',function(){
      stopAll(v);
      v.muted=false;v.currentTime=0;
      v.play().catch(function(){v.muted=true;v.play().catch(function(){})});
      c.classList.add('playing');
    });
    if(matchMedia('(hover:hover)').matches){
      c.addEventListener('mouseenter',function(){if(!c.classList.contains('playing')){v.muted=true;v.play().catch(function(){})}});
      c.addEventListener('mouseleave',function(){if(v.muted){v.pause();v.currentTime=0}});
    }
    v.addEventListener('click',function(){v.pause()});
    v.addEventListener('pause',function(){c.classList.remove('playing')});
    v.addEventListener('ended',function(){c.classList.remove('playing');v.currentTime=0});
  });
})();
