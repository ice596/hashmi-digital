/* Tappy: Hashmi Digital's mascot. A chat bubble that types. Hand-built SVG so it can blink, wave and type forever. */
(function(){
  var C={b:'#FF6A1F',s:'#E5530E',h:'#FFA36B',e:'#26202E',ck:'#FF9A80',leg:'#EF5E15',sole:'#2B2733',lace:'#D9D5DF'};
  function arm(pose,side){
    var L=side==='l';
    if(pose==='cheer') return L
      ? '<g class="tp-arm tp-arm-l"><path d="M54 130 Q30 96 22 64" stroke="'+C.b+'" stroke-width="26" stroke-linecap="round" fill="none"/><circle cx="22" cy="60" r="16" fill="'+C.b+'"/></g>'
      : '<g class="tp-arm tp-arm-r"><path d="M246 130 Q270 96 278 64" stroke="'+C.b+'" stroke-width="26" stroke-linecap="round" fill="none"/><circle cx="278" cy="60" r="16" fill="'+C.b+'"/></g>';
    if(pose==='wave' && !L) return '<g class="tp-arm tp-wave"><path d="M248 150 Q276 128 284 92" stroke="'+C.b+'" stroke-width="26" stroke-linecap="round" fill="none"/><circle cx="285" cy="86" r="17" fill="'+C.b+'"/><path d="M272 76 q4 -10 10 -6" stroke="'+C.s+'" stroke-width="4" stroke-linecap="round" fill="none" opacity=".5"/></g>';
    if(pose==='point' && !L) return '<g class="tp-arm tp-point"><path d="M248 150 Q280 150 300 136" stroke="'+C.b+'" stroke-width="24" stroke-linecap="round" fill="none"/><circle cx="302" cy="134" r="15" fill="'+C.b+'"/></g>';
    /* hands on hips */
    return L
      ? '<g class="tp-arm tp-arm-l"><path d="M48 150 Q22 172 40 198 Q52 210 70 204" stroke="'+C.b+'" stroke-width="24" stroke-linecap="round" stroke-linejoin="round" fill="none"/></g>'
      : '<g class="tp-arm tp-arm-r"><path d="M252 150 Q278 172 260 198 Q248 210 230 204" stroke="'+C.b+'" stroke-width="24" stroke-linecap="round" stroke-linejoin="round" fill="none"/></g>';
  }
  function shoe(x){
    return '<g><path d="M'+(x-30)+' 334 C'+(x-30)+' 314 '+(x-14)+' 308 '+x+' 309 C'+(x+18)+' 310 '+(x+32)+' 318 '+(x+34)+' 332 L'+(x+34)+' 338 L'+(x-30)+' 338 Z" fill="#fff"/>'+
      '<rect x="'+(x-32)+'" y="334" width="68" height="9" rx="4.5" fill="'+C.sole+'"/>'+
      '<path d="M'+(x-8)+' 316 l10 4 M'+(x-4)+' 312 l10 4" stroke="'+C.lace+'" stroke-width="3.5" stroke-linecap="round"/></g>';
  }
  window.tappy=function(pose,label){
    pose=pose||'hips';
    var id='tp'+Math.random().toString(36).slice(2,7);
    return '<svg class="tappy tp-'+pose+'" viewBox="-10 -10 330 370" role="img" aria-label="'+(label||'Tappy, the Hashmi Digital mascot')+'">'+
      '<defs><clipPath id="'+id+'"><path d="M110 22 H190 C238 22 262 46 262 102 V150 C262 204 238 230 190 230 H110 C62 230 38 204 38 150 V102 C38 46 62 22 110 22 Z"/></clipPath></defs>'+
      '<ellipse class="tp-shadow" cx="150" cy="346" rx="86" ry="9" fill="#2B2733" opacity=".08"/>'+
      '<g class="tp-legs"><rect x="110" y="214" width="28" height="104" rx="14" fill="'+C.leg+'"/><rect x="162" y="214" width="28" height="104" rx="14" fill="'+C.leg+'"/>'+shoe(122)+shoe(178)+'</g>'+
      '<g class="tp-top">'+
        arm(pose,'l')+
        '<path d="M254 118 Q282 124 298 120 Q288 140 254 160 Z" fill="'+C.b+'"/>'+
        '<path d="M110 22 H190 C238 22 262 46 262 102 V150 C262 204 238 230 190 230 H110 C62 230 38 204 38 150 V102 C38 46 62 22 110 22 Z" fill="'+C.b+'"/>'+
        '<g clip-path="url(#'+id+')"><path d="M20 196 Q150 236 280 196 V250 H20 Z" fill="'+C.s+'"/></g>'+
        '<ellipse cx="80" cy="54" rx="15" ry="8" transform="rotate(-32 80 54)" fill="'+C.h+'"/><circle cx="66" cy="74" r="4.5" fill="'+C.h+'"/>'+
        '<g class="tp-face">'+
          '<g class="tp-eyes"><ellipse cx="118" cy="100" rx="25" ry="27" fill="#fff"/><ellipse cx="184" cy="100" rx="25" ry="27" fill="#fff"/>'+
            '<g class="tp-pupils"><circle cx="124" cy="103" r="11" fill="'+C.e+'"/><circle cx="190" cy="103" r="11" fill="'+C.e+'"/><circle cx="128" cy="98" r="3.6" fill="#fff"/><circle cx="194" cy="98" r="3.6" fill="#fff"/></g></g>'+
          '<ellipse cx="94" cy="138" rx="14" ry="8.5" fill="'+C.ck+'" opacity=".75"/><ellipse cx="208" cy="138" rx="14" ry="8.5" fill="'+C.ck+'" opacity=".75"/>'+
          '<path class="tp-mouth" d="M137 132 Q151 150 165 132 Q151 138 137 132 Z" fill="#5A1A10"/>'+
        '</g>'+
        '<g class="tp-dots"><circle cx="132" cy="180" r="6.5" fill="#fff"/><circle cx="151" cy="180" r="6.5" fill="#fff"/><circle cx="170" cy="180" r="6.5" fill="#fff"/></g>'+
        arm(pose,'r')+
      '</g></svg>';
  };
  function mount(){document.querySelectorAll('[data-tappy]').forEach(function(el){if(!el.firstElementChild)el.innerHTML=window.tappy(el.getAttribute('data-tappy'),el.getAttribute('data-label'))});}
  if(document.readyState!=='loading')mount();else document.addEventListener('DOMContentLoaded',mount);
})();
